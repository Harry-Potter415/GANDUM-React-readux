import AllBlogs from "./allBlogs";
import SingleBlog from "./singleBlog";

export { AllBlogs, SingleBlog };
