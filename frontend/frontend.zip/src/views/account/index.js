import Login from "./login";
import Register from "./register";
import ForgotPassword from "./forgot-password";
import Account from "./account";

export { Login, Register, ForgotPassword, Account };
