const convertDate = date => {
  return new Date(date).toLocaleDateString();
};

export default convertDate;
