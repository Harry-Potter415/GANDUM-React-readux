export default {
  contained: {
    boxShadow:
      "0 1px 1px 0 rgba(0,0,0,0.1), 0 2px 1px -1px rgba(0,0,0,0.1), 0 1px 3px 0 rgba(0,0,0,0.1)",
    backgroundColor: "#FFFFFF",
    borderRadius: 50
  }
};
